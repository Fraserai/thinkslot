import fs from 'node:fs/promises';
import path from 'node:path';
import xlsx from 'xlsx';

type OscaRole = {
  id: string;
  title: string;
  description: string;
  salary: number;
  primaryTasks: string[];
  tooling: string[];
};

const ROOT = process.cwd();
const STRUCTURE_FILE = path.join(ROOT, 'data', 'raw', 'OSCA structure (1).xlsx');
const DESCRIPTIONS_FILE = path.join(ROOT, 'data', 'raw', 'OSCA Category Descriptions.xlsx');
const OUTPUT_FILE = path.join(ROOT, 'src', 'data', 'oscaRoles.json');

const SIX_DIGIT_CODE = /^\d{6}$/;

function normaliseText(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }

  const raw = String(value).trim();
  return raw.replace(/\s+/g, ' ');
}

function toSixDigitCode(value: unknown): string | null {
  if (value === null || value === undefined || value === '') {
    return null;
  }

  if (typeof value === 'number' && Number.isFinite(value)) {
    const asInt = Math.trunc(value);
    const asString = String(asInt);
    return SIX_DIGIT_CODE.test(asString) ? asString : null;
  }

  const asString = normaliseText(value);
  if (SIX_DIGIT_CODE.test(asString)) {
    return asString;
  }

  const decimalMatch = asString.match(/^(\d+)\.0+$/);
  if (decimalMatch && SIX_DIGIT_CODE.test(decimalMatch[1])) {
    return decimalMatch[1];
  }

  return null;
}

function getRows(workbook: xlsx.WorkBook, sheetName: string): unknown[][] {
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) {
    throw new Error(`Missing sheet \"${sheetName}\" in workbook`);
  }

  return xlsx.utils.sheet_to_json(sheet, {
    header: 1,
    raw: true,
    blankrows: false,
    defval: ''
  }) as unknown[][];
}

function findHeaderRow(rows: unknown[][], requiredHeaders: string[]): number {
  for (let i = 0; i < Math.min(rows.length, 40); i += 1) {
    const row = rows[i].map(normaliseText);
    const hasAll = requiredHeaders.every((header) => row.includes(header));
    if (hasAll) {
      return i;
    }
  }

  return -1;
}

function parseStructureOccupations(workbook: xlsx.WorkBook): Map<string, string> {
  const rows = getRows(workbook, 'Table 5');
  const headerIndex = findHeaderRow(rows, ['Identifier', 'Occupation']);
  const startIndex = headerIndex >= 0 ? headerIndex + 1 : 0;

  const occupations = new Map<string, string>();

  for (const row of rows.slice(startIndex)) {
    for (let i = 0; i < row.length - 1; i += 1) {
      const code = toSixDigitCode(row[i]);
      if (!code) {
        continue;
      }

      const title = normaliseText(row[i + 1]);
      if (!title || toSixDigitCode(title)) {
        continue;
      }

      occupations.set(code, title);
      break;
    }
  }

  return occupations;
}

function parseDescriptions(workbook: xlsx.WorkBook): Map<string, string> {
  const rows = getRows(workbook, 'Table 1');
  const headerIndex = findHeaderRow(rows, ['Identifier', 'Principal Title', 'Lead Statement']);
  if (headerIndex === -1) {
    return new Map();
  }

  const header = rows[headerIndex].map(normaliseText);
  const idIndex = header.indexOf('Identifier');
  const leadIndex = header.indexOf('Lead Statement');
  const titleIndex = header.indexOf('Principal Title');
  const inclusionIndex = header.indexOf('Inclusion and Exclusion Statements');

  const descriptions = new Map<string, string>();

  for (const row of rows.slice(headerIndex + 1)) {
    const code = toSixDigitCode(row[idIndex]);
    if (!code) {
      continue;
    }

    const lead = normaliseText(row[leadIndex]);
    const inclusion = inclusionIndex >= 0 ? normaliseText(row[inclusionIndex]) : '';
    const title = titleIndex >= 0 ? normaliseText(row[titleIndex]) : '';
    const description = lead || inclusion || title;

    descriptions.set(code, description);
  }

  return descriptions;
}

function buildRoles(occupationTitles: Map<string, string>, descriptions: Map<string, string>): OscaRole[] {
  return [...occupationTitles.entries()]
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .map(([id, title]) => ({
      id,
      title,
      description: descriptions.get(id) ?? '',
      salary: 100000,
      primaryTasks: [],
      tooling: []
    }));
}

async function main() {
  const structureWorkbook = xlsx.readFile(STRUCTURE_FILE, { raw: true });
  const descriptionsWorkbook = xlsx.readFile(DESCRIPTIONS_FILE, { raw: true });

  const occupationTitles = parseStructureOccupations(structureWorkbook);
  const descriptions = parseDescriptions(descriptionsWorkbook);
  const roles = buildRoles(occupationTitles, descriptions);

  await fs.mkdir(path.dirname(OUTPUT_FILE), { recursive: true });
  await fs.writeFile(OUTPUT_FILE, `${JSON.stringify(roles, null, 2)}\n`, 'utf8');

  const missingDescriptions = roles.filter((role) => !role.description).length;
  console.log(`Wrote ${roles.length} OSCA roles to ${OUTPUT_FILE}`);
  console.log(`Missing descriptions: ${missingDescriptions}`);
}

main().catch((error) => {
  console.error('Failed to build OSCA JSON:', error);
  process.exit(1);
});
