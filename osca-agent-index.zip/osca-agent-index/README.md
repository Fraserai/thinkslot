# OSCA Agent Index

MVP built with **Next.js + TypeScript + Tailwind CSS**.

## Features

- Real OSCA occupations generated from raw XLSX files (`/src/data/oscaRoles.json`)
- Search with autocomplete
- Role snapshot card
- `Generate Agent Emulation` button
- OpenAI-backed generation with validated fallback to stub (`/src/app/api/generate/route.ts`)
- Cost simulator comparing annual salary cost vs agent API cost
- Clean, minimal UI inspired by data-first dashboards

## Build OSCA JSON

After downloading raw files into `/data/raw/`, run this once:

```bash
npm run build:osca
```

## Run locally

```bash
npm install
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000).

## OpenAI generation

Set `OPENAI_API_KEY` in `.env.local` to enable live generation from `/api/generate`.
If the model call fails, the API automatically falls back to the local stub plan.
