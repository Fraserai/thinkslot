'use client';

import { useEffect, useMemo, useState } from 'react';
import { buildStubAgentEmulation, type AgentEmulation, type AgentGenerationRequest } from '@/lib/agentStub';
import { calculateCostScenario, formatCurrency } from '@/lib/cost';
import type { Role } from '@/types/role';

type AgentIndexAppProps = {
  roles: Role[];
};

const truncate = (value: string, max = 120) => (value.length > max ? `${value.slice(0, max - 1)}…` : value);

const SCENARIO_PRESETS = {
  light: {
    label: 'Light',
    monthlyExecutions: 200,
    avgInputTokens: 800,
    avgOutputTokens: 400
  },
  normal: {
    label: 'Normal',
    monthlyExecutions: 900,
    avgInputTokens: 2200,
    avgOutputTokens: 950
  },
  heavy: {
    label: 'Heavy',
    monthlyExecutions: 2500,
    avgInputTokens: 3500,
    avgOutputTokens: 1500
  }
} as const;

type ScenarioPreset = keyof typeof SCENARIO_PRESETS;

const MODEL_PRESETS = {
  gptClass: {
    label: 'GPT-class',
    inputPricePerMillion: 3,
    outputPricePerMillion: 12
  },
  claudeClass: {
    label: 'Claude-class',
    inputPricePerMillion: 3,
    outputPricePerMillion: 15
  },
  openSourceHosted: {
    label: 'Open-source hosted',
    inputPricePerMillion: 1,
    outputPricePerMillion: 1
  }
} as const;

type ModelPreset = keyof typeof MODEL_PRESETS;

const DEFAULT_SCENARIO_PRESET: ScenarioPreset = 'normal';
const DEFAULT_MODEL_PRESET: ModelPreset = 'gptClass';

export default function AgentIndexApp({ roles }: AgentIndexAppProps) {
  const [selectedRoleId, setSelectedRoleId] = useState(roles[0]?.id ?? '');
  const [query, setQuery] = useState(roles[0]?.title ?? '');
  const [isAutocompleteOpen, setIsAutocompleteOpen] = useState(false);

  const selectedRole = useMemo(
    () => roles.find((role) => role.id === selectedRoleId) ?? roles[0],
    [roles, selectedRoleId]
  );

  const [annualSalaryUsd, setAnnualSalaryUsd] = useState(roles[0]?.salary ?? 0);
  const [scenarioPreset, setScenarioPreset] = useState<ScenarioPreset>(DEFAULT_SCENARIO_PRESET);
  const [monthlyExecutions, setMonthlyExecutions] = useState<number>(SCENARIO_PRESETS[DEFAULT_SCENARIO_PRESET].monthlyExecutions);
  const [avgInputTokens, setAvgInputTokens] = useState<number>(SCENARIO_PRESETS[DEFAULT_SCENARIO_PRESET].avgInputTokens);
  const [avgOutputTokens, setAvgOutputTokens] = useState<number>(SCENARIO_PRESETS[DEFAULT_SCENARIO_PRESET].avgOutputTokens);
  const [modelPreset, setModelPreset] = useState<ModelPreset>(DEFAULT_MODEL_PRESET);
  const [inputPrice, setInputPrice] = useState<number>(MODEL_PRESETS[DEFAULT_MODEL_PRESET].inputPricePerMillion);
  const [outputPrice, setOutputPrice] = useState<number>(MODEL_PRESETS[DEFAULT_MODEL_PRESET].outputPricePerMillion);

  const [isGenerating, setIsGenerating] = useState(false);
  const [emulation, setEmulation] = useState<AgentEmulation | null>(null);

  useEffect(() => {
    if (!selectedRole) {
      return;
    }

    setQuery(selectedRole.title);
    setAnnualSalaryUsd(selectedRole.salary);
    setEmulation(null);
  }, [selectedRole]);

  const suggestions = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) {
      return roles.slice(0, 6);
    }

    return roles
      .filter((role) => {
        const haystack = [role.title, role.description, ...role.tooling, ...role.primaryTasks].join(' ').toLowerCase();
        return haystack.includes(normalized);
      })
      .slice(0, 6);
  }, [roles, query]);

  const costScenario = selectedRole
    ? calculateCostScenario({
        annualSalaryUsd,
        monthlyExecutions,
        avgInputTokens,
        avgOutputTokens,
        inputPricePerMillion: inputPrice,
        outputPricePerMillion: outputPrice
      })
    : null;

  const annualSavingsPct = costScenario && costScenario.annualSalaryCost > 0 ? (costScenario.annualSavings / costScenario.annualSalaryCost) * 100 : 0;

  const chooseRole = (role: Role) => {
    setSelectedRoleId(role.id);
    setQuery(role.title);
    setIsAutocompleteOpen(false);
  };

  const applyScenarioPreset = (presetKey: ScenarioPreset) => {
    const preset = SCENARIO_PRESETS[presetKey];
    setScenarioPreset(presetKey);
    setMonthlyExecutions(preset.monthlyExecutions);
    setAvgInputTokens(preset.avgInputTokens);
    setAvgOutputTokens(preset.avgOutputTokens);
  };

  const applyModelPreset = (presetKey: ModelPreset) => {
    const preset = MODEL_PRESETS[presetKey];
    setModelPreset(presetKey);
    setInputPrice(preset.inputPricePerMillion);
    setOutputPrice(preset.outputPricePerMillion);
  };

  const handleGenerate = async () => {
    if (!selectedRole) {
      return;
    }

    const payload: AgentGenerationRequest = {
      role: {
        title: selectedRole.title,
        description: selectedRole.description,
        salary: annualSalaryUsd,
        primaryTasks: selectedRole.primaryTasks,
        tools: selectedRole.tooling
      },
      scenario: {
        runsPerMonth: monthlyExecutions
      }
    };

    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error(`Generation request failed with status ${res.status}`);
      }

      const data = (await res.json()) as AgentEmulation;
      console.log('API /api/generate response:', data);
      setEmulation(data);
      setMonthlyExecutions(data.workload.runs_per_month);
      setAvgInputTokens(data.token_assumptions.input_tokens_per_run);
      setAvgOutputTokens(data.token_assumptions.output_tokens_per_run);
    } catch (error) {
      console.error('Failed to generate agent emulation:', error);
      const fallback = buildStubAgentEmulation(payload);
      setEmulation(fallback);
      setMonthlyExecutions(fallback.workload.runs_per_month);
      setAvgInputTokens(fallback.token_assumptions.input_tokens_per_run);
      setAvgOutputTokens(fallback.token_assumptions.output_tokens_per_run);
      alert('Failed to generate agent emulation. Showing fallback plan.');
    } finally {
      setIsGenerating(false);
    }
  };

  if (!selectedRole || !costScenario) {
    return (
      <section className="rounded-2xl border border-zinc-300 bg-white p-6 shadow-panel">
        <p>No role data found.</p>
      </section>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
      <section className="rounded-2xl border border-zinc-300 bg-white p-6 shadow-panel">
        <div className="mb-4">
          <label htmlFor="role-search" className="mb-2 block text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500">
            Search Roles
          </label>
          <div className="relative">
            <input
              id="role-search"
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setIsAutocompleteOpen(true);
              }}
              onFocus={() => setIsAutocompleteOpen(true)}
              onBlur={() => {
                setTimeout(() => setIsAutocompleteOpen(false), 120);
              }}
              onKeyDown={(event) => {
                if (event.key === 'Enter' && suggestions.length > 0) {
                  event.preventDefault();
                  chooseRole(suggestions[0]);
                }
              }}
              placeholder="Try: Support, Finance, Compliance..."
              className="w-full rounded-xl border border-zinc-300 bg-zinc-50 px-4 py-3 text-sm outline-none transition focus:border-zinc-900"
            />
            {isAutocompleteOpen && suggestions.length > 0 && (
              <ul className="absolute z-20 mt-2 max-h-64 w-full overflow-auto rounded-xl border border-zinc-300 bg-white p-1 shadow-xl">
                {suggestions.map((role) => (
                  <li key={role.id}>
                    <button
                      type="button"
                      onMouseDown={(event) => event.preventDefault()}
                      onClick={() => chooseRole(role)}
                      className="flex w-full items-start justify-between rounded-lg px-3 py-2 text-left transition hover:bg-zinc-100"
                    >
                      <span>
                        <span className="block text-sm font-medium text-zinc-900">{role.title}</span>
                        <span className="block text-xs text-zinc-500">{truncate(role.description)}</span>
                      </span>
                      <span className="ml-3 text-xs font-medium text-zinc-500">{formatCurrency(role.salary)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <article className="rounded-xl border border-zinc-200 bg-zinc-50 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs uppercase tracking-[0.18em] text-zinc-500">Role Snapshot</p>
              <h2 className="text-2xl font-semibold leading-tight">{selectedRole.title}</h2>
              <p className="text-sm text-zinc-600">{selectedRole.description}</p>
            </div>
            <label className="block rounded-lg border border-zinc-300 bg-white px-3 py-2">
              <span className="mb-1 block text-[10px] font-semibold uppercase tracking-[0.12em] text-zinc-500">Salary (annual)</span>
              <input
                type="number"
                min={0}
                step={1000}
                value={annualSalaryUsd}
                onChange={(event) => setAnnualSalaryUsd(Number(event.target.value) || 0)}
                className="w-40 bg-transparent font-mono text-sm outline-none"
              />
            </label>
          </div>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div>
              <p className="mb-2 text-xs uppercase tracking-[0.15em] text-zinc-500">Primary Tasks</p>
              <ul className="space-y-2 text-sm text-zinc-700">
                {selectedRole.primaryTasks.length > 0 ? selectedRole.primaryTasks.map((task) => (
                  <li key={task} className="rounded-md bg-white px-3 py-2">
                    {task}
                  </li>
                )) : (
                  <li className="rounded-md bg-white px-3 py-2 text-zinc-500">No seeded tasks yet.</li>
                )}
              </ul>
            </div>
            <div>
              <p className="mb-2 text-xs uppercase tracking-[0.15em] text-zinc-500">Tooling Surface</p>
              <div className="flex flex-wrap gap-2">
                {selectedRole.tooling.length > 0 ? selectedRole.tooling.map((tool) => (
                  <span key={tool} className="rounded-full border border-zinc-300 bg-white px-3 py-1 text-xs">
                    {tool}
                  </span>
                )) : (
                  <span className="rounded-full border border-zinc-300 bg-white px-3 py-1 text-xs text-zinc-500">No tooling seeded</span>
                )}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating}
            className="mt-6 w-full rounded-xl bg-zinc-900 px-4 py-3 text-sm font-medium text-white transition hover:bg-zinc-700 disabled:cursor-not-allowed disabled:bg-zinc-500"
          >
            {isGenerating ? 'Generating…' : 'Generate Agent Emulation'}
          </button>

          {emulation && (
            <div className="mt-5 rounded-xl border border-zinc-300 bg-white p-4">
              <p className="text-sm text-zinc-700">
                Generated plan for {selectedRole.title} at {emulation.workload.runs_per_month.toLocaleString('en-US')} runs per month.
              </p>
              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-zinc-500">Tools</h3>
                  <ul className="space-y-1 text-sm text-zinc-700">
                    {emulation.tools.map((tool) => (
                      <li key={tool}>{tool}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-zinc-500">Tasks</h3>
                  <ul className="space-y-1 text-sm text-zinc-700">
                    {emulation.tasks.map((task) => (
                      <li key={task.name}>
                        <p>
                          <span className="font-medium">{task.name}</span>{' '}
                          <span className="text-zinc-500">({(task.time_share * 100).toFixed(0)}%)</span>
                        </p>
                        <p className="text-xs text-zinc-500">{task.description}</p>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-zinc-500">Workflow</h3>
                  <ul className="space-y-1 text-sm text-zinc-700">
                    {emulation.agent_workflow_steps.map((step) => (
                      <li key={step}>{step}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </article>
      </section>

      <section className="rounded-2xl border border-zinc-300 bg-white p-6 shadow-panel">
        <div className="mb-4 flex items-end justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-zinc-500">Cost Simulator</p>
            <h2 className="text-2xl font-semibold">Human vs Agent</h2>
          </div>
          <p className="text-sm text-zinc-600">Monthly model</p>
        </div>

        <div className="space-y-3">
          <label className="block">
            <span className="mb-1 block text-xs uppercase tracking-[0.14em] text-zinc-500">Scenario Preset</span>
            <select
              value={scenarioPreset}
              onChange={(event) => applyScenarioPreset(event.target.value as ScenarioPreset)}
              className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm"
            >
              {Object.entries(SCENARIO_PRESETS).map(([key, preset]) => (
                <option key={key} value={key}>
                  {preset.label}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="mb-1 block text-xs uppercase tracking-[0.14em] text-zinc-500">Monthly Executions</span>
            <input
              type="number"
              min={0}
              value={monthlyExecutions}
              onChange={(event) => setMonthlyExecutions(Number(event.target.value) || 0)}
              className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm"
            />
          </label>

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="mb-1 block text-xs uppercase tracking-[0.14em] text-zinc-500">Input Tokens / Run</span>
              <input
                type="number"
                min={0}
                value={avgInputTokens}
                onChange={(event) => setAvgInputTokens(Number(event.target.value) || 0)}
                className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm"
              />
            </label>
            <label className="block">
              <span className="mb-1 block text-xs uppercase tracking-[0.14em] text-zinc-500">Output Tokens / Run</span>
              <input
                type="number"
                min={0}
                value={avgOutputTokens}
                onChange={(event) => setAvgOutputTokens(Number(event.target.value) || 0)}
                className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm"
              />
            </label>
          </div>

          <label className="block">
            <span className="mb-1 block text-xs uppercase tracking-[0.14em] text-zinc-500">Model Preset</span>
            <select
              value={modelPreset}
              onChange={(event) => applyModelPreset(event.target.value as ModelPreset)}
              className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm"
            >
              {Object.entries(MODEL_PRESETS).map(([key, preset]) => (
                <option key={key} value={key}>
                  {preset.label} ({preset.inputPricePerMillion}/{preset.outputPricePerMillion})
                </option>
              ))}
            </select>
          </label>

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="mb-1 block text-xs uppercase tracking-[0.14em] text-zinc-500">Input Price ($ / 1M)</span>
              <input
                type="number"
                min={0}
                step="0.1"
                value={inputPrice}
                onChange={(event) => setInputPrice(Number(event.target.value) || 0)}
                className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm"
              />
            </label>
            <label className="block">
              <span className="mb-1 block text-xs uppercase tracking-[0.14em] text-zinc-500">Output Price ($ / 1M)</span>
              <input
                type="number"
                min={0}
                step="0.1"
                value={outputPrice}
                onChange={(event) => setOutputPrice(Number(event.target.value) || 0)}
                className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm"
              />
            </label>
          </div>
        </div>

        <div className="mt-6 space-y-3 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-600">Monthly salary cost</span>
            <span className="font-semibold">{formatCurrency(costScenario.monthlySalaryCost)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-600">Monthly agent API cost</span>
            <span className="font-semibold">{formatCurrency(costScenario.monthlyAgentCost, 2)}</span>
          </div>
          <div className="h-px bg-zinc-300" />
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-600">Annual salary cost</span>
            <span className="font-semibold">{formatCurrency(costScenario.annualSalaryCost)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-600">Annual agent API cost</span>
            <span className="font-semibold">{formatCurrency(costScenario.annualAgentCost, 2)}</span>
          </div>
          <div className="h-px bg-zinc-300" />
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-900">Estimated annual savings</span>
            <span className="font-semibold text-emerald-700">{formatCurrency(costScenario.annualSavings)}</span>
          </div>
          <p className="rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs text-emerald-900">
            Agent model is {Math.max(0, annualSavingsPct).toFixed(1)}% lower than loaded salary cost in this scenario.
          </p>
        </div>
      </section>
    </div>
  );
}
