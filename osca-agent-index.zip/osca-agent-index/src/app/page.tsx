import AgentIndexApp from '@/components/AgentIndexApp';
import roles from '@/data/oscaRoles.json';
import type { Role } from '@/types/role';

export default function Home() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:py-14">
      <header className="mb-8 border-b border-zinc-300 pb-6">
        <p className="mb-2 text-xs uppercase tracking-[0.25em] text-zinc-500">MVP</p>
        <h1 className="text-4xl font-semibold leading-tight sm:text-5xl">OSCA Agent Index</h1>
        <p className="mt-3 max-w-2xl text-sm text-zinc-700 sm:text-base">
          Find a role, inspect an OSCA snapshot, generate an agent emulation plan, and compare loaded salary cost against
          estimated agent API spend.
        </p>
      </header>

      <AgentIndexApp roles={roles as Role[]} />
    </main>
  );
}
