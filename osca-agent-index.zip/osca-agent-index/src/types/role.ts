export type Role = {
  id: string;
  title: string;
  description: string;
  salary: number;
  primaryTasks: string[];
  tooling: string[];
};
